# Rife International School — Final Use Project

School details:
- Rife International School
- Musepur, Saran, Bihar
- Classes 1 to 8
- +91 98520 74561
- 94305 43279
- School logo included

This version adds local account management:
- Student login
- Teacher login
- Admin login
- Admin can create/update student and teacher accounts
- Home, Homework, Attendance, Results and Profile sections
- Data persists on the Android device

Default admin:
User ID: admin
Password: admin123

IMPORTANT:
This is a functional on-device school app, but it is NOT yet a cloud/multi-device production system. For multiple phones to share the same live student/teacher/attendance/results data, a hosted backend (for example Firebase/Supabase) and secure authentication must be configured. Do not use the demo admin password in a public deployment.

Build:
Open this folder in Android Studio, sync Gradle, run on a phone/emulator, then Build > Generate Signed App Bundle / APK.
