package com.rifeinternational.school

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

data class User(val id:String, val name:String, val role:String, val password:String, val className:String="")
data class Notice(val title:String, val body:String)
data class Homework(val subject:String, val task:String, val due:String)
data class ResultRow(val student:String, val subject:String, val marks:String)

class Store(private val c: Context) {
    private val p = c.getSharedPreferences("school", Context.MODE_PRIVATE)
    private fun users(): MutableList<User> {
        val a=JSONArray(p.getString("users","[]"))
        val out=mutableListOf<User>()
        for(i in 0 until a.length()){val o=a.getJSONObject(i);out+=User(o.getString("id"),o.getString("name"),o.getString("role"),o.getString("password"),o.optString("className"))}
        return out
    }
    fun ensureAdmin(){
        if(users().none{it.id=="admin"}) addUser(User("admin","School Admin","Admin","admin123"))
    }
    fun addUser(u:User){
        val a=JSONArray(); users().filter{it.id!=u.id}.forEach{v->a.put(JSONObject().apply{put("id",v.id);put("name",v.name);put("role",v.role);put("password",v.password);put("className",v.className)})}
        a.put(JSONObject().apply{put("id",u.id);put("name",u.name);put("role",u.role);put("password",u.password);put("className",u.className)})
        p.edit().putString("users",a.toString()).apply()
    }
    fun login(id:String,pw:String,role:String)=users().find{it.id==id&&it.password==pw&&it.role==role}
    fun allUsers()=users()
    fun setText(key:String,value:String)=p.edit().putString(key,value).apply()
    fun getText(key:String,def:String="")=p.getString(key,def) ?: def
}

class MainActivity: ComponentActivity(){
    override fun onCreate(b:Bundle?){super.onCreate(b);setContent{SchoolApp(this)}}
}

@Composable fun SchoolApp(ctx:Context){
    val store=remember{Store(ctx)}; LaunchedEffect(Unit){store.ensureAdmin()}
    var user by remember{mutableStateOf<User?>(null)}
    if(user==null) Login(store){user=it} else Dashboard(store,user!!){user=null}
}

@Composable fun Login(store:Store,onLogin:(User)->Unit){
    var id by remember{mutableStateOf("")}; var pw by remember{mutableStateOf("")}
    var role by remember{mutableStateOf("Student")}; var err by remember{mutableStateOf("")}
    Surface(Modifier.fillMaxSize()){
        Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center){
            Image(ImageBitmap.imageResource(com.rifeinternational.school.R.drawable.school_logo),null,Modifier.size(150.dp).align(Alignment.CenterHorizontally))
            Text("Rife International School",28.sp,FontWeight.Bold)
            Text("Musepur, Saran, Bihar • Classes 1–8",color=MaterialTheme.colorScheme.primary)
            Text("Contact: +91 98520 74561 • 94305 43279",12.sp)
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(id,{id=it},label={Text("User ID")},modifier=Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(pw,{pw=it},label={Text("Password")},modifier=Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Row{listOf("Student","Teacher","Admin").forEach{r->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(role==r,{role=r});Text(r);Spacer(Modifier.width(8.dp))}}}
            Button({val u=store.login(id,pw,role); if(u!=null){err="";onLogin(u)}else err="Invalid ID, password or role"},Modifier.fillMaxWidth()){Text("LOGIN")}
            if(err.isNotEmpty())Text(err,color=MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(8.dp))
            Text("Admin first login: admin / admin123",11.sp)
        }
    }
}

@Composable fun Dashboard(store:Store,u:User,onLogout:()->Unit){
    var tab by remember{mutableStateOf("Home")}
    Scaffold(topBar={TopAppBar(title={Text("Rife International School")},actions={TextButton(onLogout){Text("Logout")}})},
        bottomBar={NavigationBar{listOf("Home","Homework","Attendance","Results","Profile").forEach{t->NavigationBarItem(tab==t,{tab=t},{Text(t.first().toString())},{Text(t)})}}})
    {pad->Column(Modifier.padding(pad).padding(16.dp)){
        Text("Hello, ${u.name}",22.sp,FontWeight.Bold);Text("${u.role}${if(u.className.isNotBlank())" • Class ${u.className}" else ""}",color=MaterialTheme.colorScheme.primary);Spacer(Modifier.height(12.dp))
        when(tab){
            "Home"->Home(store,u)
            "Homework"->HomeworkPage(store,u)
            "Attendance"->AttendancePage(store,u)
            "Results"->ResultsPage(store,u)
            "Profile"->ProfilePage(store,u)
        }
    }}
}

@Composable fun Home(store:Store,u:User){
    if(u.role=="Admin"){
        var name by remember{mutableStateOf("")};var id by remember{mutableStateOf("")};var pw by remember{mutableStateOf("")};var role by remember{mutableStateOf("Student")};var cls by remember{mutableStateOf("")}
        Text("Admin • Manage Users",20.sp,FontWeight.Bold);Spacer(Modifier.height(8.dp))
        OutlinedTextField(name,{name=it},label={Text("Name")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(id,{id=it},label={Text("User ID")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(pw,{pw=it},label={Text("Password")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(cls,{cls=it},label={Text("Class (students)")},modifier=Modifier.fillMaxWidth())
        Row{listOf("Student","Teacher").forEach{r->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(role==r,{role=r});Text(r)}}}
        Button({if(id.isNotBlank()&&pw.isNotBlank()&&name.isNotBlank())store.addUser(User(id,name,role,pw,cls))}){Text("Create / Update User")}
        Spacer(Modifier.height(10.dp))
        Text("Existing accounts",FontWeight.Bold)
        LazyColumn{items(store.allUsers()){Text("${it.id} — ${it.name} — ${it.role}${if(it.className.isNotBlank())" — Class ${it.className}" else ""}",Modifier.padding(5.dp))}}
    }else{
        Info("School Notices","Welcome to Rife International School.\nYour dashboard is ready for homework, attendance and results.")
    }
}
@Composable fun HomeworkPage(store:Store,u:User){
    if(u.role=="Admin"||u.role=="Teacher"){
        var sub by remember{mutableStateOf("")};var task by remember{mutableStateOf("")};var due by remember{mutableStateOf("")}
        Text("Add Homework",20.sp,FontWeight.Bold);OutlinedTextField(sub,{sub=it},label={Text("Subject")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(task,{task=it},label={Text("Task")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(due,{due=it},label={Text("Due date")},modifier=Modifier.fillMaxWidth())
        Button({store.setText("homework","$sub|$task|$due")}){Text("Save Homework")}
    } else Info("Homework","Homework posted by your teacher will appear here.\nAdmin/Teacher can add the latest homework.")
}
@Composable fun AttendancePage(store:Store,u:User)=Info("Attendance","Attendance section is included. For a real multi-phone school deployment, connect this screen to a shared online database.")
@Composable fun ResultsPage(store:Store,u:User)=Info("Results","Results section is included. Teachers/Admin can later connect marks to the school's shared database.")
@Composable fun ProfilePage(store:Store,u:User)=Info("Profile","Name: ${u.name}\nRole: ${u.role}\nUser ID: ${u.id}\nClass: ${u.className.ifBlank{"—"}}\nRife International School\nMusepur, Saran, Bihar\n+91 98520 74561\n94305 43279")
@Composable fun Info(title:String,body:String){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text(title,20.sp,FontWeight.Bold);Spacer(Modifier.height(10.dp));Text(body)}}}
